<?php
// No direct access
defined( '_JEXEC' ) or die;

/**
 * Controller
 * @author CB9TOIIIA
 */
class MyjbzoostatControllerArticles extends JControllerLegacy
{

}