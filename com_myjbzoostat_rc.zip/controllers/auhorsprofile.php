<?php
// No direct access
defined( '_JEXEC' ) or die;

/**
 * Controller
 * @author CB9TOIIIA
 */
class MyjbzoostatControllerAuhorsprofile extends JControllerLegacy
{

}
